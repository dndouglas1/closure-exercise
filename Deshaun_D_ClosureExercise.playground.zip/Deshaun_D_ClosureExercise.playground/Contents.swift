let multiply = {
    (first: Int, second: Int) -> Int in
    return first * second
}
let result = multiply (26, 6)
print; result

